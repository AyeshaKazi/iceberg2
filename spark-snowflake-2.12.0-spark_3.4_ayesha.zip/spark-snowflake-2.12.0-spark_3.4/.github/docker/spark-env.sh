## The configuration override maybe provided, here bellow you can see
#  the container default environment (tested to work configuration).
#  For additional details refer to
#     https://github.com/apache/spark/blob/master/conf/spark-env.sh.template

## Viable options for the daemons started by the container in the standalone deploy mode
#  Note: that other options might not make sense to pass, since they might control
#        the bash invocation scenario.

# - HADOOP_CONF_DIR, to point Spark towards Hadoop configuration files

# - SPARK_MASTER_PORT / SPARK_MASTER_WEBUI_PORT, to use non-default ports for the master
# - SPARK_MASTER_OPTS, to set config properties only for the master (e.g. "-Dx=y")
# export SPARK_MASTER_OPTS="-Dnet.snowflake.jdbc.loggerImpl=net.snowflake.client.log.JDK14Logger -Djava.util.logging.config.file=/users/spark/config/logging.properties"
# - SPARK_WORKER_CORES, to set the number of cores to use on this machine
# - SPARK_WORKER_MEMORY, to set how much total memory workers have to give executors (e.g. 1000m, 2g)
# - SPARK_WORKER_PORT / SPARK_WORKER_WEBUI_PORT, to use non-default ports for the worker
# - SPARK_WORKER_DIR, to set the working directory of worker processes
# - SPARK_WORKER_OPTS, to set config properties only for the worker (e.g. "-Dx=y")
# export SPARK_WORKER_OPTS="-Dnet.snowflake.jdbc.loggerImpl=net.snowflake.client.log.JDK14Logger -Djava.util.logging.config.file=/users/spark/config/logging.properties"
# - SPARK_DAEMON_MEMORY, to allocate to the master, worker and history server themselves (default: 1g).
# - SPARK_HISTORY_OPTS, to set config properties only for the history server (e.g. "-Dx=y")
# - SPARK_SHUFFLE_OPTS, to set config properties only for the external shuffle service (e.g. "-Dx=y")
# - SPARK_DAEMON_JAVA_OPTS, to set config properties for all daemons (e.g. "-Dx=y")
# export SPARK_DAEMON_JAVA_OPTS="-Dnet.snowflake.jdbc.loggerImpl=net.snowflake.client.log.JDK14Logger -Djava.util.logging.config.file=/users/spark/config/logging.properties"
# - SPARK_DAEMON_CLASSPATH, to set the classpath for all daemons
